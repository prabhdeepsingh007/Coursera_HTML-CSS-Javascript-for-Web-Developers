    $(document).ready(function(){
/**************** Admin Profile Script Start *************/
var form_object = jQuery(".addevent");
form_object.validate({
  rules:{ 
        ename:{
            required: true,
        },
        day:{
            required: true,
        },
        duration:{
            required: true,
        },
        edate:{
            required: true,
        },
        etime:{
            required: true,
        },
        dept:{
            required: true,
        },
        description:{
            required: true,
        },
  },
    highlight: function(element) {
      jQuery(element).closest('.form-group').removeClass('has-success').addClass('has-error');
    },
    success: function(element) {
      jQuery(element).closest('.form-group').removeClass('has-error');
      jQuery(element[0]).remove();
    },
    submitHandler: function() {
        var form = $('form')[1]; 
        var formData = new FormData(form);

        $.ajax({
            url: base_url()+'/add_event_ajax.php',
            type:"POST",
            data: formData,
            dataType:"JSON",
            contentType: false, 
            processData: false,
            beforeSend: function() {
                $('.loading').show();
                $('.loading_icon').show();
            }, 
            success: function(data)
            {
                $('.loading').hide();
                $('.loading_icon').hide();
                if(data.type != 'failed'){
                    document.location.reload()
                }
                Ply.dialog("alert", data.msg);
            },
            error:function(error)
            {
                console.log(error);
                $('.loading').hide();
                $('.loading_icon').hide();
            }
        });
    }
});
});















/**************** Admin Profile Script End ***************/
