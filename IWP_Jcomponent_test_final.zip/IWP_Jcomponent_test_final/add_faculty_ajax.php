<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{
	if(isset($_POST['submit']))
	{	
			$sql = "INSERT INTO addnewfaculty (facultyName,dob,mno,email,address,eduQuali,department,description) VALUES ('".$_POST['FacultyName']."','".$_POST['dob']."','".$_POST['mno']."','".$_POST['email']."','".$_POST['Address']."','".$_POST['eduQuali']."','".$_POST['dept']."','".$_POST['description']."')";

			if ($db->query($sql) === TRUE)
			{ 	 
				echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}	

	}

	if(isset($_POST['update']))
	{		 
		
		
			$sql = "UPDATE addnewfaculty SET facultyName='".$_POST['FacultyName']."',dob='".$_POST['dob']."',address='".$_POST['Address']."',eduQuali='".$_POST['eduQuali']."',department='".$_POST['dept']."',description='".$_POST['description']."' WHERE facultyID = ".$_POST['facultyID']."";
			if ($db->query($sql) === TRUE)
			{  
				echo json_encode(array('type' => 'success','msg' => 'Faculty Data Update successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}
	   	

	}
}	


	if(isset($_GET['delete']))
	{		
		if(!empty($_GET['id']))
		{
			$sql = "DELETE FROM addnewfaculty WHERE facultyID = ".$_GET['id']."";
			if ($db->query($sql) === TRUE)
			{  
				$_SESSION['status'] = true;
				$_SESSION['msg'] = 'Faculty Record Deleted Successfully';
				
			}
			else
			{
				$_SESSION['status'] = false;
				$_SESSION['msg'] = 'Some Thing Error Occer';
			}
			header("location: ".base_url()."/view_faculty_data.php");
	   }	

	}
?>