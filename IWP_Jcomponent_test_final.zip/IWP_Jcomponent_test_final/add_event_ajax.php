<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{
	if(isset($_POST['submit']))
		{	
				$sql = "INSERT INTO events (ename,day,duration,edate,etime,dept,description) VALUES ('".$_POST['ename']."','".$_POST['day']."','".$_POST['duration']."','".$_POST['edate']."','".$_POST['etime']."','".$_POST['dept']."','".$_POST['description']."')";

				if ($db->query($sql) === TRUE)
				{ 	 
					echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
				}
				else
				{
		    		echo "Error: " . $sql . "<br>" . $db->error;
				}	

		}

	if(isset($_POST['update']))
	{		 
			
			
				$sql = "UPDATE events SET ename='".$_POST['ename']."',day='".$_POST['day']."',duration='".$_POST['duration']."',edate='".$_POST['edate']."',etime='".$_POST['etime']."',dept='".$_POST['dept']."',description='".$_POST['description']."' WHERE eventID = ".$_POST['eventID']."";

				if ($db->query($sql) === TRUE)
				{  
					echo json_encode(array('type' => 'success','msg' => 'Event Data Update successfully'));exit;
				}
				else
				{
		    		echo "Error: " . $sql . "<br>" . $db->error;
				}
		   	

	}
}	

	if(isset($_GET['delete']))
	{		
		if(!empty($_GET['id']))
		{
			$sql = "DELETE FROM events WHERE eventID = ".$_GET['id']."";
			if ($db->query($sql) === TRUE)
			{  
				$_SESSION['status'] = true;
				$_SESSION['msg'] = 'Faculty Record Deleted Successfully';
				
			}
			else
			{
				$_SESSION['status'] = false;
				$_SESSION['msg'] = 'Some Thing Error Occer';
			}
			header("location: ".base_url()."/view_events.php");
	   }	

	}	
?>