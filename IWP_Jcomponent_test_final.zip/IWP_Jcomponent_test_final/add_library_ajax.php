<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{	
	if(isset($_POST['submit']))
		{	
				$sql = "INSERT INTO library (title,author,jonor,description) VALUES ('".$_POST['title']."','".$_POST['Author']."','".$_POST['Jonor']."','".$_POST['description']."')";

				if ($db->query($sql) === TRUE)
				{ 	 
					echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
				}
				else
				{
		    		echo "Error: " . $sql . "<br>" . $db->error;
				}	

		}
}
?>	