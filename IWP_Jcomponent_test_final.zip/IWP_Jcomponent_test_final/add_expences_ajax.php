<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{
if(isset($_POST['submit']))
	{	
			$sql = "INSERT INTO expences (cost,day,expences,description) VALUES ('".$_POST['ExpencesCost']."','".$_POST['day']."','".$_POST['type']."','".$_POST['description']."')";

			if ($db->query($sql) === TRUE)
			{ 	 
				echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}	

	}
}
?>