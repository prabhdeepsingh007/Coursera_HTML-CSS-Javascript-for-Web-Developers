<?php include 'view/admin/header.php'; ?>
<script src="<?php echo base_url(); ?>/assets/js/event.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2" style="height: 593px;">
            <!-- sidebar file  -->
            <?php include 'view/admin/sidebar.php'; ?>
        </div>
        <div class="col-sm-10" style="margin-top: 15px">
            <form class="addevent" method="post" id="addevent" novalidate="novalidate">
              <div class="col-sm-12">
                  <label>Event name</label>
                    <input type="text" class="form-control custom_form_field" name="ename" placeholder="Enter The Event Name" id="ename">
              </div>
              
              <div class="col-sm-12">
                  <label>Event Day</label>
                    <input type="text" class="form-control custom_form_field" name="day" placeholder="Monday,Tuesday...." id="Address" Title="Field is required add Days only(Monday,Tuesday....)">
                    <select class="form-control custom_form_field" name="day" placeholder="Monday,Tuesday....">
                        <option>Monday</option>
                        <option>Tuesday</option>
                        <option>Wednesday</option>
                        <option>Thursday</option>
                        <option>Friday</option>
                        <option>Saturday</option>
                        <option>Sunday</option>
                      </select>
              </div>

              <div class="col-sm-12">
                  <label>Duration</label>
                    <input type="text" class="form-control custom_form_field" name="duration" placeholder="Duration of the event" id="Address">
              </div>

              <div class="col-sm-12">
                  <label>Date</label>
                    <input type="date" class="form-control custom_form_field" name="edate" placeholder="mm/dd/yyyy format" id="edate" Title="Field is required mm/dd/yyyy format only">
              </div>

              <div class="col-sm-12">
                  <label>Time</label>
                    <input type="text" class="form-control custom_form_field" name="etime" placeholder="Enter the time in 12hr format" id="Address" Title="Field is required and it should be in 12hrs format">
              </div>
             
              <div class="col-sm-12">
                  <label>Department</label>
                    
                     <select class="form-control custom_form_field" name="dept" id="dept">
                        <option>SCOPE</option>
                        <option>SELECT</option>
                        <option>SENSE</option>
                        <option>SITE</option>
                        <option>CIVIL ENGINEERING</option>
                        <option>CHEMICAL ENGINEERING</option>
                        <option>MECHENICAL ENGINEERING</option>
                      </select>
              </div>
             <div class="col-sm-12">
                 <label>Description</label>
                 <textarea class="form-control custom_form_field" rows="5" col="50" name="description"
                  placeholder="description"></textarea>
             </div>
             <div class="col-sm-12" style="margin-top: 20px;">
                 <input type="submit" class="form-control custom_form_field" name="submit" value="Add the Details">
             </div>
          </form> 
        </div>
    </div>
</div>


<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>

