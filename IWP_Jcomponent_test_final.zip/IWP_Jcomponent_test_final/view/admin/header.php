<?php
include 'function.php';
if(isset($_POST['logout'])) 
{
    session_unset();
    session_destroy();
}
if(session_check()==false) 
{
    header("Location: ".base_url()."/admin_panel_form.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href=  "<?php echo base_url(); ?>/assets/css/style.css">
	
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
	<title>Welcome User</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>

</head>
<body>
	<div class="container-fluid">
		<div class="row" style="background-color: black; z-index: 999;">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<h1  style="color: white; text-align: center;">WelCome <?php echo $_SESSION['username']; ?></h1>
			</div>
			<div class="col-sm-2">
				<div style="float: right;">
					<form method="post">
						<input type="submit" name="logout" value="logout" style="margin: 20px;">
					</form>			
				</div>
			</div>
		</div>
	</div>