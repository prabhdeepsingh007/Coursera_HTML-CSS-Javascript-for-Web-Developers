
			<div class="vertical-menu">
				  <a href="http://localhost/IWP_Jcomponent_test_final/dashboard.php" class="active">Dashboard</a>
				  <a  href="http://localhost/IWP_Jcomponent_test_final/add_faculty.php">Add Faculty</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/view_faculty_data.php">View Faculty Data</a>
				  <a  href="http://localhost/IWP_Jcomponent_test_final/add_staff.php">Add Staff</a>
				  <a  href="http://localhost/IWP_Jcomponent_test_final/view_staff_data.php">View Staff Data</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/add_expences.php">Add Expences</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/view_expences.php">View Expences</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/library_books.php">Library Books Details</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/add_events.php">Add Events</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/view_events.php">View Events</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/view_student_message.php">View Student Message</a>
		    </div>