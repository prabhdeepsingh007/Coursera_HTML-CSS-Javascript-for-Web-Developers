<?php
include 'database.php';
session_start();
function is_ajax_request()
{
	return ( ! empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
}


function base_url()
{
	return ("http://" . $_SERVER['SERVER_NAME'] .'/IWP_Jcomponent_test_final'); //base url
}

function session_check()
{
	if (isset($_SESSION['login'])) 
	{
		if ($_SESSION['login']== true) 
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
}


?>