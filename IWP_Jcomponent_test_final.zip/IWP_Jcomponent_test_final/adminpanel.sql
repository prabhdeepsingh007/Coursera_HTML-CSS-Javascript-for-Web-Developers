-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2019 at 06:54 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminpanel`
--

-- --------------------------------------------------------

--
-- Table structure for table `addfaculty`
--

CREATE TABLE `addfaculty` (
  `description` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addnewfaculty`
--

CREATE TABLE `addnewfaculty` (
  `facultyID` int(11) NOT NULL,
  `facultyName` varchar(25) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `mno` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `eduQuali` varchar(12) NOT NULL,
  `department` varchar(10) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addnewfaculty`
--

INSERT INTO `addnewfaculty` (`facultyID`, `facultyName`, `dob`, `mno`, `email`, `address`, `eduQuali`, `department`, `description`) VALUES
(6, 'Prabhdeep', '10/02/1998', '9898767564', 'psc@gmail.com', 'Indore', 'Mtech', 'SCOPE', 'qwqwkjgbk'),
(10, 'Aziz', '1997-12-13', '8976756453', 'aziz@yahoo.com', 'Baroda', 'PHD', 'SCOPE', 'Good in IWP'),
(13, 'Diljit', '1983-12-12', '9807867564', 'diljit@gmail.ccom', 'Mumbai', 'PHD', 'SENSE', 'Good in circuit Designing'),
(14, 'XYZ', '1960-12-18', '9809876543', 'rk@gmail.com', 'Indore(M.P)', 'PHD', 'MECHENICAL', 'Calculus is strong');

-- --------------------------------------------------------

--
-- Table structure for table `addstaff`
--

CREATE TABLE `addstaff` (
  `staffID` int(12) NOT NULL,
  `staffName` varchar(25) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `mno` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `eduQuali` varchar(25) NOT NULL,
  `department` varchar(25) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addstaff`
--

INSERT INTO `addstaff` (`staffID`, `staffName`, `dob`, `mno`, `email`, `gender`, `address`, `eduQuali`, `department`, `description`) VALUES
(1, 'Kamil', '12/18/1960', '9765412345', 'kk@gmail.com', 'Male', 'Shikarpur', '5 years experience', 'Staff', 'qweqe');

-- --------------------------------------------------------

--
-- Table structure for table `adminpanel`
--

CREATE TABLE `adminpanel` (
  `name` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminpanel`
--

INSERT INTO `adminpanel` (`name`, `password`) VALUES
('Prabhdeep', '123456'),
('Prabhdeep', 'NSph123456'),
('Prabhdeep', 'NSph'),
('Aziz', 'AZiz'),
('Prabhdeep', 'Password123@');

-- --------------------------------------------------------

--
-- Table structure for table `educationinfo`
--

CREATE TABLE `educationinfo` (
  `eduID` int(20) NOT NULL,
  `tpyear` varchar(20) NOT NULL,
  `tresult` varchar(20) NOT NULL,
  `tschool` varchar(100) NOT NULL,
  `tboard` varchar(20) NOT NULL,
  `twpyear` varchar(20) NOT NULL,
  `twresult` varchar(20) NOT NULL,
  `twschool` varchar(100) NOT NULL,
  `twboard` varchar(20) NOT NULL,
  `registration` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `educationinfo`
--

INSERT INTO `educationinfo` (`eduID`, `tpyear`, `tresult`, `tschool`, `tboard`, `twpyear`, `twresult`, `twschool`, `twboard`, `registration`) VALUES
(1, '2013', '9.2 CGPA', 'St. Paul', 'C.B.S.E', '2015', '92%', 'Delhi Pubic School', 'C.B.S.E', '16BCE0611'),
(2, '2013', '9.0', 'Delhi Public School', 'C.B.S.E', '2015', '86%', 'Laurels', 'C.B.S.E', '16BCE0100');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `eventID` int(10) NOT NULL,
  `ename` varchar(20) NOT NULL,
  `day` varchar(10) NOT NULL,
  `duration` int(10) NOT NULL,
  `edate` date NOT NULL,
  `etime` varchar(10) NOT NULL,
  `dept` varchar(15) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`eventID`, `ename`, `day`, `duration`, `edate`, `etime`, `dept`, `description`) VALUES
(2, 'Himalaya Stallion', 'Saturday', 2, '2018-08-12', '4:00pm', 'SCOPE', 'Health releted event');

-- --------------------------------------------------------

--
-- Table structure for table `expences`
--

CREATE TABLE `expences` (
  `expencesID` int(11) NOT NULL,
  `cost` int(11) NOT NULL,
  `day` varchar(20) NOT NULL,
  `expences` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expences`
--

INSERT INTO `expences` (`expencesID`, `cost`, `day`, `expences`, `description`) VALUES
(1, 1000, 'Monday', 'Library Books', 'Some books Brought'),
(8, 1000, 'Monday', 'Stationary Items', 'Stationary Item'),
(9, 2000, 'Friday', 'Fest Related Work', 'Halloween\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `familyinfo`
--

CREATE TABLE `familyinfo` (
  `familyID` int(10) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `fedu` varchar(20) NOT NULL,
  `fdob` varchar(20) NOT NULL,
  `foccu` varchar(20) NOT NULL,
  `freligion` varchar(20) NOT NULL,
  `fbg` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `medu` varchar(20) NOT NULL,
  `ndob` varchar(20) NOT NULL,
  `moccu` varchar(20) NOT NULL,
  `mreligion` varchar(20) NOT NULL,
  `mbg` varchar(20) NOT NULL,
  `registration` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `familyinfo`
--

INSERT INTO `familyinfo` (`familyID`, `fname`, `fedu`, `fdob`, `foccu`, `freligion`, `fbg`, `mname`, `medu`, `ndob`, `moccu`, `mreligion`, `mbg`, `registration`) VALUES
(1, 'Narinder Singh', 'B.E Civil', '10/06/1969', 'Business Man', 'Sikh', 'A+', 'Surinder Kaur', 'P.hd', '18/09/1971', 'C.E.O', 'Sikh', 'O+', '16BCE0611'),
(2, 'Rajkumar Mehta', 'B.E. Civil', '04/02/1969', 'Business Man', 'Hindu(Jain)', 'O+', 'Rakhi Mehta', 'BBA', '21/09/1970', 'House Wife', 'Hindu(Jain)', 'O+', '16BCE0100');

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE `library` (
  `libraryID` int(11) NOT NULL,
  `title` varchar(25) NOT NULL,
  `author` varchar(20) NOT NULL,
  `jonor` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`libraryID`, `title`, `author`, `jonor`, `description`) VALUES
(1, 'asd', 'asd', 'Science Fiction', 'asd'),
(2, 'Vision 2020', 'Dr. A.P.J Abdul Kala', 'Autobiography', 'A good book must read for all students'),
(3, 'Calcus For Engineers', 'Thomas Calcus', 'RELATED TO SCOPE DEP', 'Maths Book 1st year');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `messageID` int(11) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `num` varchar(20) NOT NULL,
  `edate` varchar(20) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`messageID`, `sname`, `num`, `edate`, `dept`, `description`) VALUES
(1, 'Problem releted to credit', '16BCE0611', '2018-10-21', 'SCOPE', 'qwqweeqwqe');

-- --------------------------------------------------------

--
-- Table structure for table `studentinfo`
--

CREATE TABLE `studentinfo` (
  `infoID` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `application` varchar(25) NOT NULL,
  `dob` varchar(25) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `physically` varchar(10) NOT NULL,
  `religion` varchar(10) NOT NULL,
  `bg` varchar(5) NOT NULL,
  `registration` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentinfo`
--

INSERT INTO `studentinfo` (`infoID`, `name`, `application`, `dob`, `gender`, `physically`, `religion`, `bg`, `registration`) VALUES
(1, 'Prabhdeep Singh Chawla', '2016095184', '18/11/1998', 'Male', 'NA', 'Sikh', 'A+', '16BCE0611'),
(2, 'Nakul Mehta', '2016098765', '23/10/1998', 'Male', 'NA', 'Hindu(Jain', 'O+', '16BCE0100');

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE `studentlogin` (
  `loginID` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `registration` varchar(20) NOT NULL,
  `password` varchar(25) NOT NULL,
  `cpassword` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `cemail` varchar(20) NOT NULL,
  `num` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentlogin`
--

INSERT INTO `studentlogin` (`loginID`, `fname`, `lname`, `registration`, `password`, `cpassword`, `email`, `cemail`, `num`, `address`) VALUES
(1, '', '', '16BCE0611', 'ABcd123@', '', '', '', '', ''),
(2, 'Prabhdeep', 'Chawla', '16BCE0611', 'Password123@', 'Password123@', 'psc@gmail.com', 'psc@gmail.com', '9998987675', 'Elite Tower'),
(3, '', '', '16BCE2000', 'QWer', '', '', '', '', ''),
(4, 'wkwlkn', 'dfdkfkgn', '16BCE0121', 'wfwjlj', 'sdlsjj', 'q@gmail.com', 'q@gmail.com', '987456321', 'dfljgjbb');

-- --------------------------------------------------------

--
-- Table structure for table `stud_library`
--

CREATE TABLE `stud_library` (
  `bookID` int(11) NOT NULL,
  `title` varchar(20) NOT NULL,
  `author` varchar(20) NOT NULL,
  `jonor` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  `registration` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_library`
--

INSERT INTO `stud_library` (`bookID`, `title`, `author`, `jonor`, `description`, `registration`) VALUES
(1, 'Thomas Calculus', 'Thomas', 'RELATED TO SCOPE DEP', 'Maths book', '16BCE0611'),
(2, 'maths for engineers', 'B.S Grewal', 'RELATED TO SCOPE DEP', 'Maths Ccalcus Book', ''),
(3, 'asd', 'asd', 'Science Fiction', 'asd', ''),
(4, 'asd', 'asd', 'Science Fiction', 'asd', ''),
(5, 'qwert', 'qwert', 'Science Fiction', 'qwert', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subjectsID` int(11) NOT NULL,
  `course` varchar(20) NOT NULL,
  `slot` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `credits` int(10) NOT NULL,
  `registration` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subjectsID`, `course`, `slot`, `type`, `fname`, `credits`, `registration`) VALUES
(1, 'IWP', 'B1', 'Embedded Theory Lab ', 'Prof. Jayakumar', 4, '16BCE0611'),
(2, 'PDC', 'E1', 'Embedded Theory Lab ', 'Prof. Balamurugan R', 4, '16BCE0611'),
(3, 'IP', 'G2', 'Embedded Theory And ', 'Prof Natarajan P.', 4, '16BCE0611'),
(4, 'Lean-Startup', 'TE1', 'Embedded Project', 'Prof. Sujata S', 2, '16BCE0611'),
(5, 'SIN', 'A1+TA1', 'Embedded Theory And ', 'Prof. Rajkumar R', 4, '16BCE0611'),
(6, 'ALA', 'C1+TC1+TCC1', 'Embedded Theory', 'Prof. Moumita Mandal', 4, '16BCE0611'),
(7, 'STS', 'D1+TD1+TDD1', 'Embedded Theory', '-', 1, '16BCE0611'),
(8, 'Web Minning', 'F1+TF1', 'Embedded Theory Lab', 'Prof. Balakrishnan P', 4, '16BCE0611'),
(9, 'SIN', 'A1+TA1', 'Embedded Theory Proj', 'Prof. Vijay Sherley', 4, '16BCE0100'),
(10, 'PDC', 'B1+TB1', 'Embedded Theory Lab', 'Prof. Saira Banu', 4, '16BCE0100'),
(11, 'ALA', 'C1+TC1+TCC1', 'Embedded Theory', 'Prof. Roy S', 4, '16BCE0100'),
(12, 'STS', 'D1+TD1+TDD1', 'Embedded Theory', '-', 1, '16BCE0100'),
(13, 'IWP', 'E1+TE1', 'Embedded Theory Lab', 'Prof. Jayakumar', 4, '16BCE0100'),
(14, 'Web Minning', 'F1+TF1', 'Embedded Theory Lab', 'Prof. Balakrishnan P', 4, '16BCE0100');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addnewfaculty`
--
ALTER TABLE `addnewfaculty`
  ADD PRIMARY KEY (`facultyID`);

--
-- Indexes for table `addstaff`
--
ALTER TABLE `addstaff`
  ADD PRIMARY KEY (`staffID`);

--
-- Indexes for table `educationinfo`
--
ALTER TABLE `educationinfo`
  ADD PRIMARY KEY (`eduID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`eventID`);

--
-- Indexes for table `expences`
--
ALTER TABLE `expences`
  ADD PRIMARY KEY (`expencesID`);

--
-- Indexes for table `familyinfo`
--
ALTER TABLE `familyinfo`
  ADD PRIMARY KEY (`familyID`);

--
-- Indexes for table `library`
--
ALTER TABLE `library`
  ADD PRIMARY KEY (`libraryID`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `studentinfo`
--
ALTER TABLE `studentinfo`
  ADD PRIMARY KEY (`infoID`);

--
-- Indexes for table `studentlogin`
--
ALTER TABLE `studentlogin`
  ADD PRIMARY KEY (`loginID`);

--
-- Indexes for table `stud_library`
--
ALTER TABLE `stud_library`
  ADD PRIMARY KEY (`bookID`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subjectsID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addnewfaculty`
--
ALTER TABLE `addnewfaculty`
  MODIFY `facultyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `addstaff`
--
ALTER TABLE `addstaff`
  MODIFY `staffID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `educationinfo`
--
ALTER TABLE `educationinfo`
  MODIFY `eduID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `eventID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `expences`
--
ALTER TABLE `expences`
  MODIFY `expencesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `familyinfo`
--
ALTER TABLE `familyinfo`
  MODIFY `familyID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `library`
--
ALTER TABLE `library`
  MODIFY `libraryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `studentinfo`
--
ALTER TABLE `studentinfo`
  MODIFY `infoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `studentlogin`
--
ALTER TABLE `studentlogin`
  MODIFY `loginID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stud_library`
--
ALTER TABLE `stud_library`
  MODIFY `bookID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subjectsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
