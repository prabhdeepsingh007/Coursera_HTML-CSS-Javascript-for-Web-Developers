<?php include 'view/admin/header.php'; ?>
<?php 
  if(isset($_GET['id']))
  { 
    $sql = "SELECT * FROM addstaff WHERE staffID = '".$_GET['id']."'";
    $result = $db-> query($sql);
    if($result->num_rows > 0) 
    {
    // output data of each row
    $row = $result->fetch_assoc();
  }}
?>
<script src="<?php echo base_url(); ?>/assets/js/update_staff_validation.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2" style="height: 593px;">
            <!-- sidebar file  -->
            <?php include 'view/admin/sidebar.php'; ?>
        </div>
        <div class="col-sm-10" style="margin-top: 15px">
            <form class="updatestaff" method="post" id="updatestaff" novalidate="novalidate">
           <div class="col-sm-12">
               <label>Staff Name</label>
               <input type="hidden" name="staffID" value="<?php echo $row['staffID']; ?>">
               <input type="text" class="form-control custom_form_field" name="StaffName" placeholder="Faculty Name" id="name" value="<?php echo $row['staffName']; ?>">
           </div>
           <div class="col-sm-12">
                  <label>Date of birth</label>
                    <input type="text" class="form-control custom_form_field" name="dob" placeholder="DOB" id="dob" value="<?php echo $row['dob']; ?>">
            </div>
            
            <div class="col-sm-12">
                  <label>Gender</label>
                    <input type="text" class="form-control custom_form_field" name="gender" placeholder="Gender" id="gender" value="<?php echo $row['gender']; ?>">
            </div>
            <div class="col-sm-12">
                  <label>Address</label>
                    <input type="text" class="form-control custom_form_field" name="Address" placeholder="Address" id="Address" value="<?php echo $row['address']; ?>">
            </div>
            <div class="col-sm-12">
                  <label>Educational Qualtfication</label>
                    <input type="text" class="form-control custom_form_field" name="eduQuali_exp" placeholder="edu_quali" id="eduQuali" value="<?php echo $row['eduQuali']; ?>">
            </div>
            <div class="col-sm-12">
                  <label>Department</label>
                    <input type="text" class="form-control custom_form_field" name="dept" placeholder="dept" id="dept" value="<?php echo $row['department']; ?>">
            </div>
           <div class="col-sm-12">
               <label>Description</label>
               <textarea class="form-control custom_form_field" rows="5" col="50" name="description"
                  placeholder="description"><?php echo $row['description']; ?></textarea>
           </div>
           <div class="col-sm-4"></div>
           <div class="col-sm-4" style="margin-top: 20px; text-align: center;">
               <input type="submit" class="form-control custom_form_field" name="update" value="Update">
               <a href="<?php echo base_url();?>/view_staff_data.php" class="form-control">BACK</a>

           </div>
           <div class="col-sm-4"></div>
       </form> 

        </div>
    </div>
</div>

            


<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>

