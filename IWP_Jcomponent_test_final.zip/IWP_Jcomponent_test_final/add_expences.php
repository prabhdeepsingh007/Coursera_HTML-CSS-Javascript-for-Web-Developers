<?php include 'view/admin/header.php'; ?>
<script src="<?php echo base_url(); ?>/assets/js/expences.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2" style="height: 593px;">
            <!-- sidebar file  -->
            <?php include 'view/admin/sidebar.php'; ?>
        </div>
        <div class="col-sm-10" style="margin-top: 15px">
            <form class="addexpences" method="post" id="addexpences" novalidate="novalidate">
              <div class="col-sm-12">
                  <label>Expences Cost</label>
                    <input type="number" class="form-control custom_form_field" name="ExpencesCost" placeholder="Expences Cost" id="cost">
              </div>
              
              <div class="col-sm-12">
                  <label>Day</label>
                    <input type="text" class="form-control custom_form_field" name="day" placeholder="Monday,Tuesday...." id="Address" Title="Field is required add Days only(Monday,Tuesday....)">
              </div>
             
              <div class="col-sm-12">
                  <label>Type of Expences</label>
                    
                     <select class="form-control custom_form_field" name="type" placeholder="Type" id="type">
                        <option>Stationary Items</option>
                        <option>Repair Work</option>
                        <option>Library Books</option>
                        <option>Fest Related Work</option>
                        <option>Students Welfare</option>
                        <option>Faculty And Staff Welfare</option>
                      </select>
              </div>
             <div class="col-sm-12">
                 <label>Description</label>
                 <textarea class="form-control custom_form_field" rows="5" col="50" name="description"
                  placeholder="description"></textarea>
             </div>
             <div class="col-sm-12" style="margin-top: 20px;">
                 <input type="submit" class="form-control custom_form_field" name="submit" value="Add the Details">
             </div>
          </form> 
        </div>
    </div>
</div>


<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>

