<!-- header file  -->
<?php include 'view/admin/header.php'; ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-10">
			<?php include 'view/admin/test.php'; ?>
		</div>
	</div>
</div>

<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>