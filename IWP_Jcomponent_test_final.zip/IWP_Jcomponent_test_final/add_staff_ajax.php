<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{	
	if(isset($_POST['submit']))
	{	
			$sql = "INSERT INTO addstaff (staffName,dob,mno,email,gender,address,eduQuali,department,description) VALUES ('".$_POST['StaffName']."','".$_POST['dob']."','".$_POST['mno']."','".$_POST['email']."','".$_POST['gender']."','".$_POST['Address']."','".$_POST['eduQuali_exp']."','".$_POST['dept']."','".$_POST['description']."')";

			if ($db->query($sql) === TRUE)
			{ 	 
				echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}	

	}

	if(isset($_POST['update']))
	{		 
		
		
			$sql = "UPDATE addstaff SET staffName='".$_POST['StaffName']."',dob='".$_POST['dob']."',gender='".$_POST['gender']."',address='".$_POST['Address']."',eduQuali='".$_POST['eduQuali_exp']."',department='".$_POST['dept']."',description='".$_POST['description']."' WHERE staffID = ".$_POST['staffID']."";
			if ($db->query($sql) === TRUE)
			{  
				echo json_encode(array('type' => 'success','msg' => 'Staff Data Update successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}
	   	

	}
}	



	if(isset($_GET['delete']))
	{		
		if(!empty($_GET['id']))
		{
			$sql = "DELETE FROM addstaff WHERE staffID = ".$_GET['id']."";
			if ($db->query($sql) === TRUE)
			{  
				$_SESSION['status'] = true;
				$_SESSION['msg'] = 'Staff Record Deleted Successfully';
				
			}
			else
			{
				$_SESSION['status'] = false;
				$_SESSION['msg'] = 'Some Thing Error Occer';
			}
			header("location: ".base_url()."/view_staff_data.php");
	   }	

	}

?>