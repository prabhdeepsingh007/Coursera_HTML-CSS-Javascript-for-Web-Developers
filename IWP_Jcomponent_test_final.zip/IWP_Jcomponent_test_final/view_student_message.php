<?php include 'view/admin/header.php'; ?>
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2" style="height: 593px;">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-10">
			<h3 style="text-align: center;">Book Information From Students</h1><br>
          <table class="table table-striped table-bordered">
            <tr>
              <th>S.NO.</th>
              <th>Student Name</th>
              <th>Registration Number</th>
              <th>Date</th>
              <th>Deperatment</th>
              <th>Description</th>
              
            </tr>
            <?php 
                    $sql = "SELECT * FROM message";
                    $result = $db-> query($sql);
                    if($result->num_rows > 0) 
                    {
                    // output data of each row
                      $catnum =1;
                    while($row = $result->fetch_assoc()) {
                    ?>
            <tr>
              <td><?php echo $catnum; $catnum++; ?></td>
              <td><?php echo $row["sname"];?></td>
              <td><?php echo $row["num"];?></td>
              <td><?php echo $row["edate"];?></td>
              <td><?php echo $row["dept"];?></td>
              <td><?php echo $row["description"];?></td>
             
            </tr>
            <?php
          } }
            ?>
          </table>
		</div>
	</div>
</div>
<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>