<?php include 'view/admin/header.php'; ?>
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2" style="height: 593px;position:sticky;">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-10">
			<h1 style="text-align: center;">Courses Registered This Semester</h1><br>
			<table class="table table-striped table-bordered" style="height: 17pc;">
				<tr>
				    <th>S.No</th>
				    <th>Course Title</th>
				    <th>Slot</th>
				    <th>Type Of Course</th>
				    <th>Faculty Name</th>
				    <th>Credits</th> 
				</tr>
				<?php 
                $sql = "SELECT * FROM subjects WHERE registration = '".$_SESSION['username']."'";
                $result = $db-> query($sql);
                if($result->num_rows > 0) 
                {
                // output data of each row
                	$catnum =1;
                	while($row = $result->fetch_assoc()) {
                ?>
				<tr>
				    <td><?php echo $catnum; $catnum++; ?></td>
					<td><?php echo $row["course"];?></td>
					<td><?php echo $row["slot"];?></td>
					<td><?php echo $row["type"];?></td>
					<td><?php echo $row["fname"];?></td>
					<td><?php echo $row["credits"];?></td>
				</tr>
				
				
				<?php
			} }
				?>
			</table>
		</div>
	</div>
</div>
<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>