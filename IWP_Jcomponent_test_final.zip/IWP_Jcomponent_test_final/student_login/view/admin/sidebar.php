
			<div class="vertical-menu">
				  <a href="http://localhost/IWP_Jcomponent_test_final/dashboard.php" class="active">Dashboard</a>
				  <a  href="http://localhost/IWP_Jcomponent_test_final/student_login/view_personal_info.php">View Personal Information</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/student_login/view_subjects.php">View Subjects</a>
				  <a  href="http://localhost/IWP_Jcomponent_test_final/student_login/deliver_book_request.php">Deliver Book Request Message</a>
				  <a  href="http://localhost/IWP_Jcomponent_test_final/student_login/view_event.php">View Events</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/student_login/send_message.php">Send Message</a>
				  <a href="http://localhost/IWP_Jcomponent_test_final/view_expences.php">Payment Process</a>
		    </div>