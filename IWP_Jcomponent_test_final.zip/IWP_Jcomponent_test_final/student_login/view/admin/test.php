<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function () {

//Better to construct options first and then pass it as a parameter
var options = {
	title: {
		text: "Daily Expences Report of University"              
	},
	data: [              
	{
		// Change type to "doughnut", "line", "splineArea", etc.
		type: "column",
		dataPoints: [
			{ label: "1",  y: 10  },
			{ label: "2", y: 15  },
			{ label: "3", y: 25  },
			{ label: "4",  y: 30  },
			{ label: "5",  y: 28  },
			{ label: "6",  y: 28  },
			{ label: "7",  y: 28  },
			{ label: "8",  y: 28  },
			{ label: "9",  y: 28  },
			{ label: "10",  y: 28  },
			{ label: "11",  y: 28  },
			{ label: "12",  y: 28  },
			{ label: "13",  y: 8  },
			{ label: "14",  y: 28  },
			{ label: "15",  y: 28  },
			{ label: "16",  y: 14  },
			{ label: "17",  y: 28  },
			{ label: "18",  y: 12  },
			{ label: "19",  y: 28  },
			{ label: "20",  y: 28  },
			{ label: "21",  y: 28  },
			{ label: "22",  y: 10  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 30  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
			{ label: "22",  y: 28  },
		]
	}
	]
};

$("#chartContainer").CanvasJSChart(options);
}
</script>
<style type="text/css">
.canvasjs-chart-credit
{
	display: none;
}
</style>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 1100px;"></div>
<script type="text/javascript" src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
</body>
</html>