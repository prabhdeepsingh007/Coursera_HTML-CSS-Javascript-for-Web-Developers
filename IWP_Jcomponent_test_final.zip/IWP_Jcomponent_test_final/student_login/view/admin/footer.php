<script type="text/javascript">
  function base_url()
  {
    return '<?php echo base_url(); ?>';
  }


</script>
<div class="container-fluid" style="background-color: black;color: white;margin-top: 259px;">
  <div class="row">
    <div class="col-sm-2">
      
    </div>
    <div class="col-sm-3">
      <p>Copyright:SDSC Department</p>
    </div>
    <div class="col-sm-2">
      
    </div>
    <div class="col-sm-4">
      <p>Contact us at:admin@gmail.com</p>
    </div>

  </div>
</div>

</body>
</html>