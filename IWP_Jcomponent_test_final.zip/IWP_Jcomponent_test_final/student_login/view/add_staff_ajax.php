<?php
include 'function.php';
include 'database.php';

	if(isset($_POST['submit']))
	{	
			$sql = "INSERT INTO addstaff (staffName,dob,gender,address,eduQuali,department,description) VALUES ('".$_POST['StaffName']."','".$_POST['dob']."','".$_POST['gender']."','".$_POST['Address']."','".$_POST['eduQuali_exp']."','".$_POST['dept']."','".$_POST['description']."')";

			if ($db->query($sql) === TRUE)
			{ 	 
				echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}	

	}