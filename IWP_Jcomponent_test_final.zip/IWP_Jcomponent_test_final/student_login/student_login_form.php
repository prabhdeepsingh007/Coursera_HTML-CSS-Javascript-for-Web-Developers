<?php
include 'function.php';
if(session_check()==true) 
{
    header("Location: ".base_url()."/front_page.php");
}

?>


<!DOCTYPE html>
<html>
<head>
  <title>Student_login_page</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
    <script src="<?php echo base_url(); ?>/assets/js/student_login.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
    <style type="text/css">
      body {
        background-color: #2e2b2b;
      }
      

    </style>
</head>
<body style="background-image: url('https://www.pixelstalk.net/wp-content/uploads/2016/11/Farming-free-hd-wallpapers.jpg');background-attachment: fixed;">
<div class="container">
    <div class="row">
      <div class="col-sm-3">
        
      </div>
    <div class="col-sm-6 form_login">
      <form class="student_login" method="post" id="newajaxForm" novalidate="novalidate">
        <div class="row">
          <h2 style="text-align: center; color: #ffffff; background-color: #332f2f;    box-shadow: 1px 0px 3px 0px;">Welcome Student</h2>
        </div><br>
        <div class="row">
          <div class="col-sm-6">
            <label>Enter Registration Number</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="text" name="reg" placeholder="Enter Registration Number" required>
        </div>
        </div><br>
        <div class="row">
          <div class="col-sm-6">
            <label>Enter Password</label>
          </div>
        <div class="col-sm-6">
          <input class="form-control" type="password" name="password" placeholder=" Of the type Abb@..." required title="This field is reguired and 1 special character 1 small and 1 uppercase character and minimum length of 4 reguired" >
            </div>
        </div><br>
        <div class="row">
          <div class="col-sm-3">
            
          </div>
          <div class="col-sm-4">
              <input class="form-control" type="submit" name="login">
          </div>

        </div>
      </form>
      <br>
      <form method="POST" action="register.php" target="_blank">
        <div class="col-sm-8">
          <h4><b>New User Click on the button Below</b></h2>
        </div>
        <br><br>
        <div class="col-sm-4">
                <input class="form-control" type="submit" name="sign_up" value="Sign Up" style="width: 155px;margin-left: 122px;">
        </div>
      </form>
    </div>
  </div>
</div>
  
</div>
<script type="text/javascript">
  function base_url()
  {
    return '<?php echo base_url();?>';
  }
</script>
</body> 
</html>