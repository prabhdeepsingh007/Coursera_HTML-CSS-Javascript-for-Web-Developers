<?php include 'view/admin/header.php'; ?>
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2" style="height: 593px;position:sticky;">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-1">
			
		</div>
		<div class="col-sm-2">
			<a href="personal.php"><button type="button" class="btn btn-primary" style="margin-top: 56px;">Personal Information</button></a>
		</div>
		<div class="col-sm-1">
			
		</div>
		<div class="col-sm-2">
			<a href="family.php"><button type="button" class="btn btn-primary" style="margin-top: 56px;">Family Information</button></a>
		</div>
		<div class="col-sm-1">
			
		</div>
		<div class="col-sm-2">
			<a href="edu.php"><button type="button" class="btn btn-primary" style="margin-top: 56px;">Academic Information</button></a>
		</div>	
	</div>
</div>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2" >
			
		</div>
		<div class="col-sm-2">
			
		</div>
		<div class='col-sm-8'>
			<h2 style="margin-top: -392px;">Click on button to view information</h2>
		</div>
	</div>
</div>	
		
<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>