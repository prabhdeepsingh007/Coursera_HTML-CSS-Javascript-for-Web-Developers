<!-- header file  -->
<?php include 'view/admin/header.php'; ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-1">
			
		</div>
		<div class="col-sm-8" style="margin-top: 54px;border: 2px dashed black;">
			<h3>The side bar contains the following information</h2>
			<h3>1. <b>ViewPersonal Information</b>- To view Your personal details</h2>
			<h3>2. <b>Vies Subjects</b>- To view Your subject registered current semester</h2>
			<h3>3. <b>Deliver Book Request</b>-If any book is not there you can put its request online</h2>
			<h3>4. <b>View Events</b>-To view Upcoming events</h2>
			<h3>5. <b>Send Message</b>-If any query you can send online</h2>
		</div>
		<div class="col-sm-1">
			
		</div>
	</div>
</div>

<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>