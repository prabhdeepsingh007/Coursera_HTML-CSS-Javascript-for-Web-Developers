<?php include 'view/admin/header.php'; ?>
<script src="<?php echo base_url(); ?>/assets/js/library.js"></script>
<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-2" style="height: 593px;position:sticky;">
            <!-- sidebar file  -->
            <?php include 'view/admin/sidebar.php'; ?>
        </div>
        <div class="col-sm-10" style="margin-top: 15px">
            <form class="book_request" method="post" id="book_request" novalidate="novalidate">
              <div class="col-sm-12">
                  <label>Title</label>
                    <input type="text" class="form-control custom_form_field" name="title" placeholder="Title of the book" id="title">
              </div>
              
              <div class="col-sm-12">
                  <label>Author</label>
                    <input type="text" class="form-control custom_form_field" name="Author" placeholder="Author of the book" id="author">
              </div>
             
              <div class="col-sm-12">
                  <label>Jonor Of The Book</label>
                    
                     <select class="form-control custom_form_field" name="Jonor" placeholder="Jonor" id="Jonor">
                        <option>Science Fiction</option>
                        <option>Autobiography</option>
                        <option>GATE</option>
                        <option>UPSC</option>
                        <option>GRE/GMAT</option>
                        <option>CAT/MBA Entrances</option>
                        <option>RELATED TO SCOPE DEPARTMENT</option>
                        <option>RELATED TO SELECT DEPARTMENT</option>
                        <option>RELATED TO SENSE DEPARTMENT</option>
                        <option>RELATED TO SITE DEPARTMENT</option>
                        <option>RELATED TO CIVIL ENGINEERING DEPARTMENT</option>
                        <option>RELATED TO CHEMICAL ENGINEERING DEPARTMENT</option>
                        <option>RELATED TO MECHENICAL ENGINEERING DEPARTMENT</option>
                      </select>
              </div>
             <div class="col-sm-12">
                 <label>Description</label>
                 <textarea class="form-control custom_form_field" rows="5" col="50" name="description"
                  placeholder="description"></textarea>
             </div>
             <div class="col-sm-12" style="margin-top: 20px;">
                 <input type="submit" class="form-control custom_form_field" name="submit" value="Add the Details">
             </div>
          </form> 
        </div>
    </div>
</div>


<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>

