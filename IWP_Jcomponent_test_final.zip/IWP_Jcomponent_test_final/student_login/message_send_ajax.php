<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{
if(isset($_POST['submit']))
	{	
			$sql = "INSERT INTO message (sname,num,edate,dept,description) VALUES ('".$_POST['sname']."','".$_POST['num']."','".$_POST['edate']."','".$_POST['dept']."','".$_POST['description']."')";

			if ($db->query($sql) === TRUE)
			{ 	 
				echo json_encode(array('type' => 'success','msg' => 'New record created successfully'));exit;
			}
			else
			{
	    		echo "Error: " . $sql . "<br>" . $db->error;
			}	

	}
}
?>