<?php
include 'function.php';
include 'database.php';

if(is_ajax_request())
{
	if(isset($_POST['login']) && preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $_POST['password']))
	{
		$sql = "SELECT * FROM studentlogin WHERE registration = '".$_POST['reg']."' and password = '".($_POST['password'])."'";

		$result = $db-> query($sql);
		if($result->num_rows > 0)
		{
			$_SESSION['username'] = $_POST['reg'];
			$_SESSION['login'] = true;
			echo json_encode(array('type' => 'success','msg' => 'Login Successful'));exit;
		}
		else
		{
			echo json_encode(array('type' => 'failed','msg' => 'Invalid Credentials'));

		}
	}
	else
	{
		echo json_encode(array('type' => 'failed','msg' => 'Invalid password pattern(one character, one Numeric digit, and one special character, and length in between 8-12)'));	
	}
}
?>	