<?php include 'view/admin/header.php'; ?>
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">

		
	<div class="row">
		<div class="col-sm-2" style="height: 593px;position:sticky;">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-10">
			<h1 style="text-align: center;">Academic Information</h1><br>
			<table class="table table-striped table-bordered">
				<tr>
				    <th>Educational Details</th>
				    <th>Information</th> 
				</tr>
				<?php 
                $sql = "SELECT * FROM educationinfo WHERE registration = '".$_SESSION['username']."'";
                $result = $db-> query($sql);
                if($result->num_rows > 0) 
                {
                // output data of each row
                	$catnum =1;
                	$row = $result->fetch_assoc()
                ?>
				<tr>
				    <td>10th Passing Year</td>
				    <td><?php echo $row["tpyear"] ?></td>
				    
				</tr>
				<tr>
				  	<td>10th Percentage or CGPA</td>
				    <td><?php echo $row["tresult"] ?></td>
				   
				</tr>
				<tr>
				  	<td>10th School</td>
				    <td><?php echo $row["tschool"] ?></td>
				   
				</tr>
				<tr>
				  	<td>10th Board</td>
				    <td><?php echo $row["tboard"] ?></td>
				   
				</tr>
				<tr>
				  	<td>12th Passing Year</td>
				    <td><?php echo $row["twpyear"] ?></td>
				  
				</tr>
				<tr>
				  	<td>12th Percentage or CGPA</td>
				    <td><?php echo $row["twresult"] ?></td>
				    
				</tr>
				<tr>
				  	<td>12th School</td>
				    <td><?php echo $row["twschool"] ?></td>
				   
				</tr>
				<tr>
				  	<td>12th School</td>
				    <td><?php echo $row["twboard"] ?></td>
				   
				</tr>

				<?php
			} 
				?>
			</table>
			<a href="view_personal_info.php"><button type="button" class="btn btn-primary" style="margin-left: 432px;;">Go back to view information page</button></a>
		</div>
	</div>
</div>
<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>