<?php include 'view/admin/header.php'; ?>
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2" style="height: 593px;position:sticky;">
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-10">
			<h1 style="text-align: center;">Family Information</h1><br>
			<table class="table table-striped table-bordered">
				<tr>
				    <th>Family Details</th>
				    <th>Information</th> 
				</tr>
				<?php 
                $sql = "SELECT * FROM familyinfo WHERE registration = '".$_SESSION['username']."'";
                $result = $db-> query($sql);
                if($result->num_rows > 0) 
                {
                // output data of each row
                	$catnum =1;
                	$row = $result->fetch_assoc()
                ?>
				<tr>
				    <td>Father's Name</td>
				    <td><?php echo $row["fname"] ?></td>
				    
				</tr>
				<tr>
				  	<td>Education Qualification</td>
				    <td><?php echo $row["fedu"] ?></td>
				   
				</tr>
				<tr>
				  	<td>Date of Birth</td>
				    <td><?php echo $row["fdob"] ?></td>
				   
				</tr>
				<tr>
				  	<td>Occupation</td>
				    <td><?php echo $row["foccu"] ?></td>
				  
				</tr>
				<tr>
				  	<td>Religion</td>
				    <td><?php echo $row["freligion"] ?></td>
				    
				</tr>
				<tr>
				  	<td>Blood Group</td>
				    <td><?php echo $row["fbg"] ?></td>
				   
				</tr>

				<tr>
				    <td>Mother's Name</td>
				    <td><?php echo $row["mname"] ?></td>
				    
				</tr>
				<tr>
				  	<td>Education Qualification</td>
				    <td><?php echo $row["medu"] ?></td>
				   
				</tr>
				<tr>
				  	<td>Date of Birth</td>
				    <td><?php echo $row["ndob"] ?></td>
				   
				</tr>
				<tr>
				  	<td>Occupation</td>
				    <td><?php echo $row["moccu"] ?></td>
				  
				</tr>
				<tr>
				  	<td>Religion</td>
				    <td><?php echo $row["mreligion"] ?></td>
				    
				</tr>
				<tr>
				  	<td>Blood Group</td>
				    <td><?php echo $row["mbg"] ?></td>
				   
				</tr>
				
				<?php
			} 
				?>
			</table>
			<a href="view_personal_info.php"><button type="button" class="btn btn-primary" style="    margin-left: 432px;;">Go back to view information page</button></a>
		</div>
	</div>
	
<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>