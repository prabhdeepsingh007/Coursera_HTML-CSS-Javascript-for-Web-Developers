
<?php
include "database.php";
if(isset($_POST["login"]))
{

	if(empty($_POST["fname"]))
		echo "First Name is required";
	else
	{
		$fname=test_input($_POST["fname"]);
	}

	if(empty($_POST["lname"]))
		echo "Last Name is required";
	else
		$lname=test_input($_POST["lname"]);

	if(empty($_POST["reg"]))
		echo "Registration Number is required";
	else
		$username=test_input($_POST["reg"]);

	if(empty($_POST["password"]))
		echo "Password is required";
	else
		$password=test_input($_POST["password"]);

	if(empty($_POST["cpassword"]))
		echo "Confirm Password is required";
	else
		$confirmpassword=test_input($_POST["cpassword"]);

	if(empty($_POST["Email"]))
		echo "Email is required";
	else
		$email=test_input($_POST["Email"]);

	if(empty($_POST["cemail"]))
		echo "Confirmemail is required";
	else
		$confirmemail=test_input($_POST["cemail"]);

	if(empty($_POST["Number"]))
		echo "Number is required";
	else
		$number=test_input($_POST["Number"]);
	if(empty($_POST["address"]))
		echo "Address is required";
	else
		$address=test_input($_POST["address"]);


 	$sql = "INSERT INTO studentlogin (fname,lname,registration,password,cpassword,email,cemail,num,address) VALUES('$fname','$lname','$username','$password','$confirmpassword','$email','$confirmemail','$number','$address')";
 	if ($db->query($sql) === TRUE)
	{ 	 
		echo "<script> alert('Registered');
    window.location.href='http://localhost/IWP_Jcomponent_test_final/student_login/student_login_form.php';
    </script>";
    exit;
	}
	else
	{
	    echo "Error: " . $sql . "<br>" . $db->error;
	}
} 	

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>