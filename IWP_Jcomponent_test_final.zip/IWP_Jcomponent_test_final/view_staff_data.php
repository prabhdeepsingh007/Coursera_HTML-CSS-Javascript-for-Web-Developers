<?php include 'view/admin/header.php'; ?>
	<script src="<?php echo base_url(); ?>/assets/js/Ply.js"></script>
  	<link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/Ply.css">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2" style="height: 593px;">
			<!-- sidebar file  -->
			<?php include 'view/admin/sidebar.php'; ?>
		</div>
		<div class="col-sm-10">
			<h1 style="text-align: center;">Details of the Categories</h1><br>
			<table class="table table-striped table-bordered">
				<tr>
					<th>S.NO.</th>
					<th>Staff Name</th>
					<th>Date of Birth</th>
					<th>Mobile Number</th>
					<th>Email Id</th>
					<th>Gender</th>
					<th>Address</th>
					<th>Educational Qualification/Experience</th>
					<th>Department</th>
					<th>Description</th>
					<th>Action</th>
				</tr>
				<?php 
                $sql = "SELECT * FROM addstaff";
                $result = $db-> query($sql);
                if($result->num_rows > 0) 
                {
                // output data of each row
                	$catnum =1;
                while($row = $result->fetch_assoc()) {
                ?>
				<tr>
					<td><?php echo $catnum; $catnum++; ?></td>
					<td><?php echo $row["staffName"];?></td>
					<td><?php echo $row["dob"];?></td>
					<td><?php echo $row["mno"];?></td>
					<td><?php echo $row["email"];?></td>
					<td><?php echo $row["gender"];?></td>
					<td><?php echo $row["address"];?></td>
					<td><?php echo $row["eduQuali"];?></td>
					<td><?php echo $row["department"];?></td>
					<td><?php echo $row["description"];?></td>
					<td><a href="<?php echo base_url(); ?>/update_staff.php?id=<?php echo $row["staffID"]; ?>" class="form-control" style="width: 76%; float: left;">Update</a>

						<a href="<?php echo base_url(); ?>/add_staff_ajax.php?id=<?php echo $row["staffID"]; ?>&delete=true" style="width: 76%; float: left;" class="form-control">Delete</a></td>
				</tr>
				<?php
			} }
				?>
			</table>
		</div>
	</div>
</div>
<!-- footer file  -->
<?php include 'view/admin/footer.php'; ?>